<script src="{{asset('frontend/libs/jquery/jquery.min.js')}}"></script>
<script src="{{asset('frontend/libs/owlcarousel/owl.carousel.min.js')}}"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu-916DdpKAjTmJNIgngS6HL_kDIKU0aU&amp;callback=myMap"></script> -->
<script src="{{asset('frontend/libs/validation/validation.js')}}"></script>
<script src="{{asset('frontend/js/validation.js')}}"></script>
<script src="{{asset('frontend/js/core.js')}}"></script>
@yield('scripts')