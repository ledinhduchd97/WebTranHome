<?php

namespace App\Http\Controllers;
use App\HeaderFooter;
use App\SetUp;
use App\PageIndex;
use App\House;
use App\Image;
use App\AboutUs;
use App\PartnerView;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hf = HeaderFooter::get()->first(); //Content text của header và footer
        $pageindexs = PageIndex::get()->first(); //Content text của page index
        $aboutus = AboutUs::get()->first();
        // dd($aboutus);
        $partner = PartnerView::get()->first();
        $setup = SetUp::get()->first();
        // dd($partner);
        $houses = House::where('active_status',1)->get();
        return view('index',compact('hf','pageindexs','houses','aboutus','partner','setup'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
